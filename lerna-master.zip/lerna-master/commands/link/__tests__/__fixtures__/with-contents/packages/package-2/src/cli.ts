#!/usr/bin/env node
/* eslint-disable node/shebang */
console.log("Hello, world!");
