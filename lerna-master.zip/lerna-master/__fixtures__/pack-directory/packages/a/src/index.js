"use strict";

module.exports = "A";
